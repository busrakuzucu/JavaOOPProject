package Modeller.Departmanlar;

public interface Departman {

    /*


       İpucu : Departman üzerinden bu methodlar kullanilacak fakat, calisanin departmani hangisi ise onun özellikleri
       gecerli olacak. Bu bize daha dinamik bir yapi sağlar.


     */

    int getZamOrani();
    String getDepartmanKodu();


}
